# GigRide V3 Android

Native Android version of GigRide for phone-only use.

## Included
- Foreground GPS tracking that continues with the screen off while the service is active.
- Lifetime tracked kilometres.
- Daily income, expense and net calculations.
- Fuel fill history and actual km/L between fuel fills.
- Odometer calibration.
- Voice commands and an Auto Mic loop while the app remains open.
- JSON/CSV export.
- GitHub Actions debug APK build.

## Build
GitHub Actions -> Build GigRide V3 APK -> Run workflow.

The APK appears under the workflow run's Artifacts as `GigRide-V3-debug-APK`.

## Important Android behavior
Start GPS from the visible app. Android restricts starting certain foreground services from the background. The GPS service uses a `location` foreground-service type and a persistent notification.
