package com.gigride.v3;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.os.*;
import java.util.Locale;

public class LocationForegroundService extends Service {
    private static final int NOTIF_ID = 3001;
    private LocationManager lm;
    private Location last;
    private double tripKm = 0;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        lm = (LocationManager)getSystemService(LOCATION_SERVICE);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("tracking","GigRide Tracking",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Continuous GPS trip tracking");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification notification(String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this,0,i,
                PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this,"tracking")
                : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("GigRide V3 GPS")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(pi)
                .setPriority(Notification.PRIORITY_LOW)
                .build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification("GPS tracking active"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(NOTIF_ID, notification("GPS tracking active"));
        }
        Store.setTracking(this,true);
        startUpdates();
        return START_STICKY;
    }

    private void startUpdates() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,3000L,5f,listener,Looper.getMainLooper());
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000L,10f,listener,Looper.getMainLooper());
            }
        } catch(Exception e) { stopSelf(); }
    }

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            if (last != null) {
                float d = last.distanceTo(loc);
                if (d >= 5 && d < 1000) {
                    tripKm += d/1000.0;
                    Store.setKm(LocationForegroundService.this,
                            Store.getKm(LocationForegroundService.this) + d/1000.0);
                }
            }
            last = loc;
            String text = String.format(Locale.getDefault(),
                    "GPS active • %.2f km this session",tripKm);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .notify(NOTIF_ID,notification(text));
        }
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
        @Override public void onStatusChanged(String provider,int status,Bundle extras) {}
    };

    @Override public void onDestroy() {
        try { if (lm != null) lm.removeUpdates(listener); } catch(Exception ignored) {}
        Store.setTracking(this,false);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
