package com.gigride.v3;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class Store {
    private static final String PREF = "gigride_v3";
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public static double getKm(Context c) { return Double.longBitsToDouble(p(c).getLong("km", Double.doubleToLongBits(0))); }
    public static void setKm(Context c, double v) { p(c).edit().putLong("km", Double.doubleToLongBits(v)).apply(); }

    public static double getBaseOdo(Context c) { return Double.longBitsToDouble(p(c).getLong("baseOdo", Double.doubleToLongBits(0))); }
    public static void setBaseOdo(Context c, double v) { p(c).edit().putLong("baseOdo", Double.doubleToLongBits(v)).apply(); }

    public static double getTarget(Context c) { return Double.longBitsToDouble(p(c).getLong("target", Double.doubleToLongBits(0))); }
    public static void setTarget(Context c, double v) { p(c).edit().putLong("target", Double.doubleToLongBits(v)).apply(); }

    public static boolean tracking(Context c) { return p(c).getBoolean("tracking", false); }
    public static void setTracking(Context c, boolean v) { p(c).edit().putBoolean("tracking", v).apply(); }

    public static String getTrips(Context c) { return p(c).getString("trips", "[]"); }
    public static void setTrips(Context c, String v) { p(c).edit().putString("trips", v).apply(); }

    public static String getTx(Context c) { return p(c).getString("tx", "[]"); }
    public static void setTx(Context c, String v) { p(c).edit().putString("tx", v).apply(); }

    public static String getFuel(Context c) { return p(c).getString("fuel", "[]"); }
    public static void setFuel(Context c, String v) { p(c).edit().putString("fuel", v).apply(); }

    public static void addTransaction(Context c, String type, double amount, String note) {
        try {
            JSONArray a = new JSONArray(getTx(c));
            JSONObject o = new JSONObject();
            o.put("date", System.currentTimeMillis());
            o.put("type", type);
            o.put("amount", amount);
            o.put("note", note == null ? "" : note);
            a.put(o);
            setTx(c, a.toString());
        } catch (Exception ignored) {}
    }

    public static void addFuel(Context c, double litres, double price, double odo, String station) {
        try {
            JSONArray a = new JSONArray(getFuel(c));
            JSONObject o = new JSONObject();
            o.put("date", System.currentTimeMillis());
            o.put("litres", litres);
            o.put("price", price);
            o.put("odo", odo);
            o.put("station", station == null ? "" : station);
            a.put(o);
            setFuel(c, a.toString());
            addTransaction(c, "Expense", litres * price, "Fuel");
        } catch (Exception ignored) {}
    }

    public static double sumToday(Context c, String type) {
        double sum = 0;
        String today = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.getDefault()).format(new java.util.Date());
        try {
            JSONArray a = new JSONArray(getTx(c));
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                if (!type.equals(o.optString("type"))) continue;
                String d = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.getDefault()).format(new java.util.Date(o.optLong("date")));
                if (today.equals(d)) sum += o.optDouble("amount");
            }
        } catch(Exception ignored) {}
        return sum;
    }

    public static double todayFuel(Context c) {
        double sum = 0;
        String today = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.getDefault()).format(new java.util.Date());
        try {
            JSONArray a = new JSONArray(getFuel(c));
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                String d = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.getDefault()).format(new java.util.Date(o.optLong("date")));
                if (today.equals(d)) sum += o.optDouble("litres") * o.optDouble("price");
            }
        } catch(Exception ignored) {}
        return sum;
    }

    public static double actualMileage(Context c) {
        try {
            JSONArray a = new JSONArray(getFuel(c));
            if (a.length() < 2) return 0;
            JSONObject b = a.getJSONObject(a.length()-1);
            JSONObject a0 = a.getJSONObject(a.length()-2);
            double litres = b.optDouble("litres");
            double distance = b.optDouble("odo") - a0.optDouble("odo");
            return litres > 0 && distance > 0 ? distance / litres : 0;
        } catch(Exception e) { return 0; }
    }
}
