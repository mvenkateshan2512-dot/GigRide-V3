package com.gigride.v3;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.*;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_LOC=100, REQ_MIC=101, REQ_NOTIF=102;
    private LinearLayout root, content;
    private TextView todayNet,todayIncome,todayExpense,todayFuel,dashKm,dashNetKm,dashGrossKm,dashFuelKm,gpsHealth,accuracy;
    private TextView actualMileage,txList,tripStatus,voiceStatus,heard;
    private EditText targetInput,incomeInput,expenseInput,fuelLitres,fuelPrice,fuelOdo,fuelStation,baseOdo;
    private SpeechRecognizer recognizer;
    private boolean autoMic=false;
    private long tripStart=0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,17,27));
        buildUi();
        requestPermissionsIfNeeded();
        refresh();
    }

    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(dp(8),dp(6),dp(8),dp(6)); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.LTGRAY); e.setInputType(2|8192); e.setPadding(dp(8),dp(6),dp(8),dp(6)); return e; }
    private LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(10),dp(8),dp(10),dp(8)); c.setBackgroundColor(Color.rgb(20,35,48)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(dp(6),dp(6),dp(6),dp(6)); c.setLayoutParams(p); return c; }

    private void buildUi(){
        ScrollView sv=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(7,17,27)); sv.addView(root); setContentView(sv);
        LinearLayout head=card(); TextView h=tv("🏍️ GigRide V3",22); h.setTextColor(Color.rgb(0,230,118)); head.addView(h); head.addView(tv("GPS • Finance • Fuel • Voice Manager",13)); root.addView(head);

        LinearLayout tabs=new LinearLayout(this); tabs.setPadding(dp(4),0,dp(4),0);
        Button home=btn("🏠 Home"), drive=btn("📍 Drive"), money=btn("💰 Money"), reports=btn("📊 Reports");
        tabs.addView(home,new LinearLayout.LayoutParams(0,-2,1)); tabs.addView(drive,new LinearLayout.LayoutParams(0,-2,1)); tabs.addView(money,new LinearLayout.LayoutParams(0,-2,1)); tabs.addView(reports,new LinearLayout.LayoutParams(0,-2,1)); root.addView(tabs);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content);
        home.setOnClickListener(v->showHome()); drive.setOnClickListener(v->showDrive()); money.setOnClickListener(v->showMoney()); reports.setOnClickListener(v->showReports());
        showHome();
    }

    private void clear(){ content.removeAllViews(); }

    private void showHome(){
        clear();
        LinearLayout c=card(); c.addView(tv("TODAY'S NET",12)); todayNet=tv("₹0",30); c.addView(todayNet);
        todayIncome=tv("Income ₹0",13); todayExpense=tv("Expenses ₹0",13); todayFuel=tv("Fuel ₹0",13);
        c.addView(todayIncome); c.addView(todayExpense); c.addView(todayFuel); content.addView(c);

        c=card(); c.addView(tv("📈 TODAY AT A GLANCE",14));
        dashKm=tv("Distance: 0.0 km",16); dashNetKm=tv("Net / km: ₹0.00",14); dashGrossKm=tv("Gross / km: ₹0.00",14); dashFuelKm=tv("Fuel / km: ₹0.00",14);
        c.addView(dashKm); c.addView(dashNetKm); c.addView(dashGrossKm); c.addView(dashFuelKm); content.addView(c);

        c=card(); c.addView(tv("🎯 DAILY NET TARGET",14)); targetInput=input("Target ₹"); c.addView(targetInput); Button save=btn("Save Target"); c.addView(save); save.setOnClickListener(v->{Store.setTarget(this,num(targetInput)); refresh();}); content.addView(c);

        c=card(); c.addView(tv("🛡️ TRACKING HEALTH",14)); gpsHealth=tv("",14); accuracy=tv("Accuracy: —",14); c.addView(gpsHealth); c.addView(accuracy); content.addView(c);
    }

    private void showDrive(){
        clear();
        LinearLayout c=card(); c.addView(tv("📍 DRIVE / GPS",18));
        tripStatus=tv(Store.tracking(this)?"GPS TRACKING ACTIVE":"GPS IDLE",16); c.addView(tripStatus);
        Button start=btn("▶ START GPS TRIP"), stop=btn("■ STOP GPS TRIP");
        c.addView(start); c.addView(stop);
        start.setOnClickListener(v->startTrip()); stop.setOnClickListener(v->stopTrip());
        c.addView(tv("The app uses an Android foreground location service so GPS can continue while the screen is off. Keep the persistent notification enabled.",12));
        content.addView(c);

        c=card(); c.addView(tv("🎙️ VOICE / AUTO MIC",18));
        voiceStatus=tv("Voice ready",14); heard=tv("Heard: —",13); c.addView(voiceStatus); c.addView(heard);
        Button mic=btn("🎙️ TAP TO SPEAK"), auto=btn("🔊 AUTO MIC OFF"); c.addView(mic); c.addView(auto);
        mic.setOnClickListener(v->listenOnce()); auto.setOnClickListener(v->{autoMic=!autoMic; auto.setText(autoMic?"🔊 AUTO MIC ON":"🔊 AUTO MIC OFF"); if(autoMic) listenOnce(); else stopRecognition();});
        content.addView(c);
    }

    private void showMoney(){
        clear();
        LinearLayout c=card(); c.addView(tv("💰 INCOME / EXPENSE",18));
        incomeInput=input("Income ₹"); expenseInput=input("Expense ₹"); EditText note=new EditText(this); note.setHint("Note"); note.setTextColor(Color.WHITE); note.setHintTextColor(Color.LTGRAY);
        c.addView(incomeInput); c.addView(note); Button ib=btn("Add Income"); c.addView(ib); ib.setOnClickListener(v->{double x=num(incomeInput); if(x>0)Store.addTransaction(this,"Income",x,note.getText().toString()); refresh();});
        c.addView(expenseInput); Button eb=btn("Add Expense"); c.addView(eb); eb.setOnClickListener(v->{double x=num(expenseInput); if(x>0)Store.addTransaction(this,"Expense",x,note.getText().toString()); refresh();}); content.addView(c);

        c=card(); c.addView(tv("⛽ ACTUAL FUEL FILL",18));
        fuelLitres=input("Litres"); fuelPrice=input("₹ / litre"); fuelOdo=input("Odometer km"); fuelStation=new EditText(this); fuelStation.setHint("Station (optional)"); fuelStation.setTextColor(Color.WHITE); fuelStation.setHintTextColor(Color.LTGRAY);
        c.addView(fuelLitres); c.addView(fuelPrice); c.addView(fuelOdo); c.addView(fuelStation); Button fb=btn("Save Fuel Fill"); c.addView(fb); actualMileage=tv("",13); c.addView(actualMileage);
        fb.setOnClickListener(v->{double l=num(fuelLitres),p=num(fuelPrice),o=num(fuelOdo); if(l>0&&p>0&&o>0){Store.addFuel(this,l,p,o,fuelStation.getText().toString()); refresh();}}); content.addView(c);

        c=card(); c.addView(tv("🧭 ODOMETER CALIBRATION",16)); baseOdo=input("Starting physical odometer km"); c.addView(baseOdo); Button bo=btn("Save Base Odometer"); c.addView(bo); bo.setOnClickListener(v->{Store.setBaseOdo(this,num(baseOdo)); refresh();}); content.addView(c);
    }

    private void showReports(){
        clear(); LinearLayout c=card(); c.addView(tv("📊 REPORTS",18)); txList=tv("",13); c.addView(txList); content.addView(c);
        c=card(); c.addView(tv("BACKUP",16)); Button json=btn("Export JSON"); Button csv=btn("Export CSV"); c.addView(json); c.addView(csv);
        json.setOnClickListener(v->shareText(buildJson(),"gigride_v3.json")); csv.setOnClickListener(v->shareText(buildCsv(),"gigride_v3.csv")); content.addView(c); refresh();
    }

    private double num(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
    private void refresh(){
        if(todayNet==null)return;
        double inc=Store.sumToday(this,"Income"), exp=Store.sumToday(this,"Expense"), fuel=Store.todayFuel(this), net=inc-exp;
        todayIncome.setText(String.format(Locale.getDefault(),"Income ₹%.0f",inc));
        todayExpense.setText(String.format(Locale.getDefault(),"Expenses ₹%.0f",exp));
        todayFuel.setText(String.format(Locale.getDefault(),"Fuel ₹%.0f",fuel));
        todayNet.setText(String.format(Locale.getDefault(),"₹%.0f",net));
        double km=Store.getKm(this), nk=km>0?net/km:0, gk=km>0?inc/km:0, fk=km>0?fuel/km:0;
        dashKm.setText(String.format(Locale.getDefault(),"Distance: %.1f km",km));
        dashNetKm.setText(String.format(Locale.getDefault(),"Net / km: ₹%.2f",nk));
        dashGrossKm.setText(String.format(Locale.getDefault(),"Gross / km: ₹%.2f",gk));
        dashFuelKm.setText(String.format(Locale.getDefault(),"Fuel / km: ₹%.2f",fk));
        if(targetInput!=null)targetInput.setText(Store.getTarget(this)>0?String.valueOf(Store.getTarget(this)):"");
        if(baseOdo!=null)baseOdo.setText(Store.getBaseOdo(this)>0?String.valueOf(Store.getBaseOdo(this)):"");
        if(gpsHealth!=null)gpsHealth.setText(Store.tracking(this)?"GPS: ACTIVE":"GPS: IDLE");
        if(actualMileage!=null){double m=Store.actualMileage(this); actualMileage.setText(m>0?String.format(Locale.getDefault(),"Actual mileage: %.2f km/L",m):"Actual mileage appears after two fuel fills.");}
        if(txList!=null)txList.setText(buildReport());
        if(tripStatus!=null)tripStatus.setText(Store.tracking(this)?"GPS TRACKING ACTIVE":"GPS IDLE");
    }

    private String buildReport(){
        try{JSONArray a=new JSONArray(Store.getTx(this)); StringBuilder s=new StringBuilder();
            for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i); s.append(new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date(o.optLong("date"))))
            .append(" • ").append(o.optString("type")).append(" • ₹").append(o.optDouble("amount")).append(" • ").append(o.optString("note")).append("\n");}
            return s.length()>0?s.toString():"No transactions recorded.";
        }catch(Exception e){return "No transactions recorded.";}
    }

    private void startTrip(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestLocation();return;}
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); return;}
        Intent i=new Intent(this,LocationForegroundService.class);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        tripStart=System.currentTimeMillis(); refresh();
    }
    private void stopTrip(){stopService(new Intent(this,LocationForegroundService.class)); refresh();}

    private void requestPermissionsIfNeeded(){requestLocation(); if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);}
    private void requestLocation(){if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOC);}
    private void requestMic(){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_MIC);}

    private void listenOnce(){
        requestMic();
        if(!SpeechRecognizer.isRecognitionAvailable(this)){voiceStatus.setText("Speech recognition is not available on this phone.");return;}
        stopRecognition();
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){voiceStatus.setText("Listening… say: start trip, stop trip, income 500, expense 100, fuel 300");}
            public void onResults(Bundle b){ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(r!=null&&!r.isEmpty()){heard.setText("Heard: \""+r.get(0)+"\"");parseVoice(r.get(0).toLowerCase(Locale.getDefault()));}}
            public void onError(int e){voiceStatus.setText("Voice error: "+e); if(autoMic)new Handler().postDelayed(()->listenOnce(),1000);}
            public void onEndOfSpeech(){voiceStatus.setText(autoMic?"Auto Mic waiting…":"Voice ready");}
            public void onBeginningOfSpeech(){voiceStatus.setText("Listening…");}
            public void onBufferReceived(byte[] b){} public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){} public void onRmsChanged(float r){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
        recognizer.startListening(i);
    }
    private void stopRecognition(){if(recognizer!=null){try{recognizer.destroy();}catch(Exception ignored){} recognizer=null;}}
    private void parseVoice(String s){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)").matcher(s); double amount=m.find()?Double.parseDouble(m.group(1)):0;
        if(s.contains("start")||s.contains("begin")||s.contains("timer")){startTrip();return;}
        if(s.contains("stop")||s.contains("end")){stopTrip();return;}
        if(s.contains("fuel")||s.contains("petrol")){if(amount>0)Store.addTransaction(this,"Expense",amount,"Fuel (voice)");refresh();return;}
        if(s.contains("income")||s.contains("received")||s.contains("payment")){if(amount>0)Store.addTransaction(this,"Income",amount,"Voice");refresh();return;}
        if(s.contains("expense")||s.contains("spent")){if(amount>0)Store.addTransaction(this,"Expense",amount,"Voice");refresh();}
    }

    private String buildJson(){return "{\"km\":"+Store.getKm(this)+",\"baseOdo\":"+Store.getBaseOdo(this)+",\"target\":"+Store.getTarget(this)+",\"transactions\":"+Store.getTx(this)+",\"fuel\":"+Store.getFuel(this)+"}";}
    private String buildCsv(){StringBuilder s=new StringBuilder("Date,Type,Amount,Note\n");try{JSONArray a=new JSONArray(Store.getTx(this));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);s.append(o.optLong("date")).append(",").append(o.optString("type")).append(",").append(o.optDouble("amount")).append(",").append(o.optString("note").replace(","," ")).append("\n");}}catch(Exception ignored){}return s.toString();}
    private void shareText(String text,String name){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,name);i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Export GigRide data"));}
    @Override protected void onResume(){super.onResume();refresh();}
    @Override protected void onDestroy(){stopRecognition();super.onDestroy();}
}
