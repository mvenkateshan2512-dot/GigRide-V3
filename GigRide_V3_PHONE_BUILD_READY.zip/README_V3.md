# GigRide V3 — Native Android Background Service

## Purpose
Native Android foundation for persistent Driver Mode:
- Foreground service
- Microphone foreground-service type
- Location foreground-service type
- Auto speech recognition loop
- en-IN speech
- On-device recognizer when available
- Visible persistent notification
- Permission handling

## Important Android behavior
The user must open GigRide and start Driver Mode while the activity is visible. Android restricts creating microphone/location foreground services from the background on modern versions.

## Next implementation
1. Add Google FusedLocationProvider for actual background GPS points.
2. Port the GigRide V2 transaction database/schema.
3. Connect parsed voice commands to income/expense/fuel/trip records.
4. Add Finance Manager sync.
5. Add boot/restart recovery only where Android permits it.
6. Add Vivo-specific battery/background settings guidance.

## Build
Open the project in Android Studio, sync Gradle, then build an APK.


## Finance Manager V9.2 Sync — INCLUDED
V3 now has a durable native FinanceSyncManager. Every voice transaction is converted into the same V9.2 envelope used by the existing GigRide HTML:
- `category`: Gig Income / Fuel Expense / Vehicle Expense
- `source`: platform
- `account`: Cash / UPI / SBI / HDFC / Paytm
- `type`: credit / debit
- `amount`
- `note`
- unique `gig_...` id
- `schema`: FinanceManagerV9.2

Transactions are queued locally so they are not lost if Finance Manager is unavailable.

The current Finance Manager HTML uses browser `BroadcastChannel` plus browser `localStorage`; a native Android process cannot directly mutate another browser app's localStorage. Therefore the V3 project includes the exact sync payload and durable queue. For fully automatic cross-app sync, Finance Manager must be given a native bridge/API or bundled into the same Android application.
