# Finance Manager V9.2 Bridge for GigRide V3

The existing GigRide HTML sends Finance Manager entries using:
- BroadcastChannel: `fm_v9_2_sync_channel`
- localStorage keys: `financemanager_v9_2_data`, `fm_data`, `finance_manager_data`

The native V3 app cannot directly write another browser application's localStorage.
Therefore V3 now uses the SAME V9.2 transaction envelope and keeps a durable pending queue.

## Envelope
```json
{
  "id":"gig_...",
  "date":"22/08/2026",
  "time":"04:30 AM",
  "category":"Gig Income",
  "source":"Uber",
  "account":"UPI",
  "type":"credit",
  "amount":850,
  "note":"GigRide V3 voice: received 850 from uber upi",
  "timestamp":"...",
  "syncSource":"GigRide V3",
  "schema":"FinanceManagerV9.2"
}
```

## Final automatic bridge
To make the native app automatically write into the Finance Manager app, the Finance Manager itself must expose a native bridge/API or be packaged inside the same Android application. The existing web implementation currently uses BroadcastChannel and browser localStorage, which are browser-local mechanisms.

V3 therefore NEVER silently discards a transaction: it queues every entry and exposes the exact V9.2 payload for import/bridge.
