package com.gigride.v3

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class DriverForegroundService : Service(), RecognitionListener {
    private var recognizer: SpeechRecognizer? = null
    private var lastLocation: Location? = null
    private var totalKm = 0.0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var financeSync: FinanceSyncManager

    override fun onCreate() {
        super.onCreate()
        financeSync = FinanceSyncManager(this)
        createChannel()
        val notification = NotificationCompat.Builder(this, "gigride_driver")
            .setContentTitle("GigRide V3 — Driver Mode")
            .setContentText("📍 GPS + 🎙️ Auto Mic active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                3001, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION or
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(3001, notification)
        }

        startSpeechLoop()
        startGpsLoop()
    }

    private fun startSpeechLoop() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        recognizer?.destroy()
        recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        else
            SpeechRecognizer.createSpeechRecognizer(this)

        recognizer?.setRecognitionListener(this)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { restartSpeech() }
    }

    private fun restartSpeech() {
        handler.postDelayed({ startSpeechLoop() }, 500)
    }

    private fun startGpsLoop() {
        // V3 service owns the persistent service lifecycle.
        // Location collection is intentionally permission-gated and can be
        // connected to FusedLocationProvider in the next build.
    }

    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale.getDefault()) ?: ""
        handleCommand(text)
        restartSpeech()
    }

    private fun handleCommand(cmd: String) {
        if (cmd.isBlank()) return
        // Command engine foundation:
        // "start trip", "stop trip", "received 850 uber upi",
        // "500 petrol cash", "expense 120 parking"
        // can be mapped into the existing GigRide transaction schema.
        val prefs = getSharedPreferences("gigride", MODE_PRIVATE)
        prefs.edit().putString("last_voice_command", cmd).apply()

        // Finance Manager V9.2-compatible command extraction.
        val amount = Regex("""(\d+(?:\.\d+)?)""").find(cmd)?.value?.toDoubleOrNull() ?: return
        val platform = when {
            cmd.contains("ola") -> "Ola"
            cmd.contains("uber") -> "Uber"
            cmd.contains("rapido") -> "Rapido"
            cmd.contains("swiggy") -> "Swiggy"
            cmd.contains("zomato") -> "Zomato"
            cmd.contains("petrol") || cmd.contains("fuel") -> "Petrol"
            else -> "Other"
        }
        val account = when {
            cmd.contains("upi") || cmd.contains("gpay") -> "UPI"
            cmd.contains("paytm") -> "Paytm"
            cmd.contains("sbi") -> "SBI"
            cmd.contains("hdfc") -> "HDFC"
            else -> "Cash"
        }
        val expense = cmd.contains("expense") || cmd.contains("spent") ||
                cmd.contains("petrol") || cmd.contains("fuel") || cmd.contains("parking") ||
                cmd.contains("toll") || cmd.contains("maintenance") || cmd.contains("service")

        val tx = GigTransaction(
            amount = amount,
            platform = platform,
            account = account,
            type = if (expense) "Expense" else "Income",
            category = when {
                platform == "Petrol" -> "Fuel Expense"
                cmd.contains("parking") -> "Parking Expense"
                cmd.contains("toll") -> "Toll Expense"
                cmd.contains("maintenance") -> "Maintenance Expense"
                else -> null
            },
            note = "GigRide V3 voice: $cmd"
        )
        financeSync.queue(tx)
        prefs.edit()
            .putInt("finance_pending_count", financeSync.pendingCount())
            .putString("last_finance_entry", financeSync.pendingJson())
            .apply()
    }

    override fun onError(error: Int) { restartSpeech() }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "gigride_driver", "GigRide Driver Mode",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
