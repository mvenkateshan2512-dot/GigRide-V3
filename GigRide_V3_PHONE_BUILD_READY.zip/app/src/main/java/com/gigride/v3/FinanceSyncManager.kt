package com.gigride.v3

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class GigTransaction(
    val amount: Double,
    val platform: String,
    val account: String,
    val type: String,
    val category: String? = null,
    val note: String? = null
)

class FinanceSyncManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("gigride_finance_sync", Context.MODE_PRIVATE)
    private val key = "pending_v92_transactions"

    fun queue(tx: GigTransaction): JSONObject {
        val now = Date()
        val v92 = JSONObject().apply {
            put("id", "gig_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}")
            put("date", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(now))
            put("time", SimpleDateFormat("hh:mm a", Locale.getDefault()).format(now))
            put("category", tx.category ?: if (tx.type.equals("Income", true)) "Gig Income"
                else if (tx.platform.equals("Petrol", true)) "Fuel Expense" else "Vehicle Expense")
            put("source", tx.platform)
            put("account", tx.account)
            put("type", if (tx.type.equals("Income", true)) "credit" else "debit")
            put("amount", tx.amount)
            put("note", tx.note ?: "GigRide: ${tx.platform} (${tx.account})")
            put("timestamp", now.toISOString())
            put("syncSource", "GigRide V3")
            put("schema", "FinanceManagerV9.2")
        }
        val list = JSONArray(prefs.getString(key, "[]"))
        list.put(v92)
        prefs.edit().putString(key, list.toString()).apply()
        return v92
    }

    fun pendingCount(): Int = JSONArray(prefs.getString(key, "[]")).length()

    fun pendingJson(): String = prefs.getString(key, "[]") ?: "[]"

    fun markAllExported() {
        prefs.edit().putString(key, "[]").apply()
    }

    private fun Date.toISOString(): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(this)
}
