package com.gigride.v3

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val req = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val status = findViewById<TextView>(R.id.status)
        val start = findViewById<Button>(R.id.start)
        val stop = findViewById<Button>(R.id.stop)
        val sync = findViewById<Button>(R.id.sync)

        start.setOnClickListener {
            requestPermissionsIfNeeded()
            if (hasPermissions()) {
                ContextCompat.startForegroundService(
                    this, Intent(this, DriverForegroundService::class.java)
                )
                status.text = "🟢 DRIVER MODE ACTIVE\nGPS + Auto Mic running"
            }
        }

        stop.setOnClickListener {
            stopService(Intent(this, DriverForegroundService::class.java))
            status.text = "⚪ Driver Mode stopped"
        }

        sync.setOnClickListener {
            val json = FinanceSyncManager(this).pendingJson()
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("GigRide Finance Manager V9.2 Sync", json))
            Toast.makeText(this, "Finance Manager V9.2 sync payload copied. Pending: ${FinanceSyncManager(this).pendingCount()}", Toast.LENGTH_LONG).show()
            status.text = "🟡 Finance sync queue ready\n${FinanceSyncManager(this).pendingCount()} pending transaction(s)"
        }
    }

    private fun hasPermissions(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.ACCESS_FINE_LOCATION
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.POST_NOTIFICATIONS
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), req)
    }
}
