# GigRide V3 — Build APK from your Android phone

This package is prepared for GitHub Actions, so the Android phone only needs a browser.

## Steps

1. Create/sign in to a GitHub account.
2. Create a NEW repository, for example `GigRide-V3`.
3. Upload the contents of this ZIP to the repository (not the ZIP itself).
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab.
6. Choose **Build GigRide V3 APK**.
7. Tap **Run workflow** if it has not already started.
8. Wait for the build to finish.
9. Open the completed workflow run.
10. Under **Artifacts**, download `GigRide-V3-debug-APK`.
11. Extract the downloaded artifact if GitHub gives you a ZIP.
12. Tap `app-debug.apk`.
13. Android may ask permission to install unknown apps for your browser/file manager. Allow it for that app only, then install.

## What the APK contains

- Native foreground service for microphone + location
- Auto speech recognition loop
- en-IN recognition
- Finance Manager V9.2 transaction queue/sync envelope
- GigRide V3 dashboard foundation

## Important

This is a DEBUG APK intended for your own testing. A signed release build should be created after the app is tested on your Vivo phone.

The Android project uses Gradle/Android Gradle Plugin, and GitHub Actions supplies the cloud build machine.
